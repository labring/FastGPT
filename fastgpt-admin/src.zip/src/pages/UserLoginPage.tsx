import React, { useState, useEffect } from 'react';
import config from '../config';
import './UserLoginPage.css';

interface UserLoginPageProps {
  onNavigateToAdmin?: () => void;
}

const UserLoginPage: React.FC<UserLoginPageProps> = ({ onNavigateToAdmin }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [redirectUrl, setRedirectUrl] = useState('');

  // 获取重定向URL参数
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const redirect = urlParams.get('redirect');
    if (redirect) {
      setRedirectUrl(redirect);
      console.log('检测到重定向URL:', redirect);
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    if (!formData.username || !formData.password) {
      setError('请填写用户名和密码');
      return false;
    }

    if (!isLoginMode) {
      if (!formData.email) {
        setError('请填写邮箱地址');
        return false;
      }
      if (formData.password !== formData.confirmPassword) {
        setError('两次输入的密码不一致');
        return false;
      }
      if (formData.password.length < 6) {
        setError('密码长度至少6位');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setLoading(true);
    setError('');

    try {
      // 调用 Spring Boot 后端 API
      const endpoint = isLoginMode ? '/auth/login' : '/auth/register';
      const requestData = isLoginMode 
        ? { username: formData.username, password: formData.password }
        : { 
            username: formData.username, 
            email: formData.email, 
            password: formData.password 
          };

      const response = await fetch(`${config.AUTH_API_URL}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });
      
      const data = await response.json();
      
      if (data.code === 1) {
        if (isLoginMode) {
          // 登录成功
          localStorage.setItem('user-token', data.data.token);
          localStorage.setItem('user-info', JSON.stringify(data.data));
          
          // 设置cookie（用于代理服务器验证）
          document.cookie = `auth_token=${data.data.token}; path=/; max-age=86400; SameSite=Lax`;
          
          // 同时设置带域名的cookie，用于跨域访问
          document.cookie = `auth_token=${data.data.token}; domain=10.14.53.120; path=/; max-age=86400; SameSite=Lax`;
          
          // 跳转到原来的分享页面
          if (redirectUrl) {
            console.log('跳转到原始页面:', redirectUrl);
            // 如果重定向URL包含token参数，直接跳转；否则添加token参数
            const url = new URL(redirectUrl);
            if (!url.searchParams.has('token')) {
              url.searchParams.set('token', data.data.token);
            }
            window.location.href = url.toString();
          } else {
            // 如果没有重定向URL，跳转到默认页面
            window.location.href = config.FASTGPT_URL;
          }
        } else {
          // 注册成功，切换到登录模式
          setIsLoginMode(true);
          setFormData(prev => ({ ...prev, email: '', confirmPassword: '' }));
          setError('');
          // 可以显示成功提示
          alert('注册成功！请使用用户名和密码登录。');
        }
      } else {
        setError(data.msg || (isLoginMode ? '登录失败' : '注册失败'));
      }
    } catch (error) {
      console.error('请求失败:', error);
      setError('网络请求失败，请检查服务器是否运行');
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  return (
    <div className="user-login-body">
      <div className="user-login-container">
        <div className="logo-section">
          <h1>FastGPT 认证系统</h1>
          <p>{isLoginMode ? '用户登录' : '用户注册'}</p>
        </div>
        
        <div className="mode-toggle">
          <button 
            className={isLoginMode ? 'active' : ''}
            onClick={() => {
              setIsLoginMode(true);
              setError('');
              setFormData(prev => ({ ...prev, email: '', confirmPassword: '' }));
            }}
          >
            登录
          </button>
          <button 
            className={!isLoginMode ? 'active' : ''}
            onClick={() => {
              setIsLoginMode(false);
              setError('');
            }}
          >
            注册
          </button>
        </div>
        
        {error && (
          <div className="error-message">
            {error}
          </div>
        )}
        
        <div className="form-section">
          <div className="form-group">
            <label htmlFor="username">用户名</label>
            <input
              type="text"
              id="username"
              name="username"
              value={formData.username}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder="请输入用户名"
              disabled={loading}
            />
          </div>
          
          {!isLoginMode && (
            <div className="form-group">
              <label htmlFor="email">邮箱</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                placeholder="请输入邮箱地址"
                disabled={loading}
              />
            </div>
          )}
          
          <div className="form-group">
            <label htmlFor="password">密码</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder={isLoginMode ? "请输入密码" : "请输入密码（至少6位）"}
              disabled={loading}
            />
          </div>
          
          {!isLoginMode && (
            <div className="form-group">
              <label htmlFor="confirmPassword">确认密码</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                placeholder="请再次输入密码"
                disabled={loading}
              />
            </div>
          )}
          
          <button
            className="submit-btn"
            onClick={handleSubmit}
            disabled={loading}
          >
            {loading ? (isLoginMode ? '登录中...' : '注册中...') : (isLoginMode ? '登录' : '注册')}
          </button>
        </div>
        
        <div className="footer-links">
          <button 
            className="link-btn"
            onClick={onNavigateToAdmin}
          >
            管理员入口
          </button>
        </div>
        
        <div className="footer">
          <p>© FastGPT 认证系统. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};

export default UserLoginPage;