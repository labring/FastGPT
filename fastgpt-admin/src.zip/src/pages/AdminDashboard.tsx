import React, { useEffect, useState } from 'react';
import config from '../config';
import './AdminDashboard.css';

interface User {
  id: string | number;
  username: string;
  email: string;
  role: string;
  createdAt?: string;
  // 新增兼容字段
  userId?: number;
  userName?: string;
  create_time?: string;
  role_id?: number;
}

interface ChatLog {
  id: string | number;
  userId: string | number;
  username: string;
  email: string;
  question: string;
  answer: string;
  timestamp?: string;
  category?: string; // 添加分类字段
  // 新增兼容后端字段
  createTime?: string;
  shareId?: string;
  outLinkUid?: string;
  appId?: string;
  chatId?: string;
  ipAddress?: string;
}

// 预定义的分类选项
const CATEGORIES = [
  { value: '', label: '全部分类' },
  { value: '计算机', label: '计算机' },
  { value: '医疗', label: '医疗' },
  { value: '教育', label: '教育' },
  { value: '商业', label: '商业' },
  { value: '科学', label: '科学' },
  { value: '生活', label: '生活' },
  { value: '娱乐', label: '娱乐' },
  { value: '其他', label: '其他' }
];

interface AdminDashboardProps {
  onLogout?: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [chatLogs, setChatLogs] = useState<ChatLog[]>([]);
  const [filteredChatLogs, setFilteredChatLogs] = useState<ChatLog[]>([]); // 过滤后的对话记录
  const [activeTab, setActiveTab] = useState<'users' | 'chats' | 'settings'>('chats'); // 默认显示chats标签页
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>(''); // 选中的分类
  const [isExporting, setIsExporting] = useState<boolean>(false); // 导出状态
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalChats: 0,
    todayChats: 0
  });

  // 获取管理员 token
  const adminToken = localStorage.getItem('admin-token') || '';
  const adminUser = JSON.parse(localStorage.getItem('admin-user') || '{}');

  // 检查管理员登录状态
  useEffect(() => {
    if (!adminToken || adminUser.role !== 'admin') {
      if (onLogout) {
        onLogout();
      }
      return;
    }
  }, [adminToken, adminUser, onLogout]);

  // 加载用户数据
  const loadUserData = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${config.AUTH_API_URL}/users`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      const result = await response.json();
      
      if (result.code === 1) {
        // 转换数据格式以匹配现有接口
        const userData = result.data.map((user: any) => ({
          id: user.userId,
          username: user.userName,
          email: user.email || '未填写',
          role: user.role_id === 2 ? 'admin' : 'user',
          createdAt: user.create_time
        }));
        
        setUsers(userData);
        setStats(prev => ({ ...prev, totalUsers: userData.length }));
      } else {
        console.error('获取用户数据失败:', result.msg);
        setUsers([]);
      }
    } catch (error) {
      console.error('加载用户数据失败:', error);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  // 自动分类函数
  const categorizeQuestion = (question: string): string => {
    const keywords = {
      '计算机': [
        // 编程相关
        '编程', '代码', '软件', '计算机', '网站', '程序', 'bug', '算法', '数据库', 
        'python', 'javascript', 'java', 'c++', 'html', 'css', '前端', '后端', 
        'AI', '人工智能', '机器学习', 'api', '框架', '开发', '调试',
        // 数学运算 - 添加数学符号和运算
        '+', '-', '×', '÷', '=', '数学', '计算', '运算', '方程', '公式', 
        '加', '减', '乘', '除', '等于', '平方', '立方', '根号', '函数',
        '几何', '代数', '统计', '概率', '微积分', '三角', '矩阵'
      ],
      '医疗': ['医院', '医生', '病', '治疗', '药', '健康', '症状', '诊断', '手术', '疫苗', '感冒', '发烧', '头痛', '医疗', '护士', '体检'],
      '教育': ['学校', '老师', '学生', '教育', '学习', '课程', '考试', '作业', '大学', '高中', '小学', '培训', '知识', '书本', '教学', '题目', '解答'],
      '商业': ['公司', '商业', '市场', '销售', '客户', '产品', '服务', '管理', '投资', '利润', '成本', '品牌', '竞争', '策略', '营销'],
      '科学': ['科学', '实验', '研究', '发现', '理论', '物理', '化学', '生物', '天文', '地理', '环境', '技术', '创新', '发明'],
      '生活': ['生活', '家庭', '朋友', '爱情', '婚姻', '孩子', '父母', '家务', '购物', '旅行', '美食', '运动', '健身', '休闲'],
      '娱乐': ['电影', '音乐', '游戏', '小说', '动画', '综艺', '明星', '娱乐', '体育', '足球', '篮球', '唱歌', '跳舞', '绘画', '摄影']
    };
    
    // 特殊处理数学表达式
    const mathPattern = /^\s*\d+\s*[\+\-\×\÷\*\/]\s*\d+\s*=?\s*$/;
    if (mathPattern.test(question) || /[0-9]+[\+\-\×\÷\*\/][0-9]+/.test(question)) {
      return '计算机';
    }
    
    // 转换为小写进行匹配
    const lowerQuestion = question.toLowerCase();
    
    for (const [category, keywordList] of Object.entries(keywords)) {
      if (keywordList.some(keyword => lowerQuestion.includes(keyword.toLowerCase()))) {
        return category;
      }
    }
    return '其他';
  };

  // 筛选聊天记录
  const filterChatLogs = (logs: ChatLog[], category: string): ChatLog[] => {
    if (!category || category === '') {
      return logs;
    }
    return logs.filter(log => log.category === category);
  };

  // 导出CSV功能
  const exportToCSV = async () => {
    const dataToExport = selectedCategory ? filteredChatLogs : chatLogs;
    
    // 如果没有数据，显示提示
    if (dataToExport.length === 0) {
      alert(selectedCategory ? `暂无${selectedCategory}相关的对话记录可导出` : '暂无对话记录可导出');
      return;
    }

    setIsExporting(true);
    try {
      // CSV 头部
      const headers = ['ID', '用户名', '邮箱', '问题', '回答', '分类', '时间'];
      
      // CSV 内容
      const csvContent = [
        headers.join(','),
        ...dataToExport.map(log => [
          log.id,
          `"${log.username}"`,
          `"${log.email}"`,
          `"${log.question.replace(/"/g, '""')}"`, // 转义双引号
          `"${log.answer.replace(/"/g, '""')}"`,
          `"${log.category || '未分类'}"`,
          `"${new Date(log.timestamp || log.createTime || '').toLocaleString()}"`
        ].join(','))
      ].join('\n');
      
      // 创建并下载文件
      const BOM = '\uFEFF'; // UTF-8 BOM
      const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      const fileName = `对话记录_${selectedCategory || '全部'}_${new Date().toLocaleString().replace(/[/:]/g, '-')}.csv`;
      link.setAttribute('href', url);
      link.setAttribute('download', fileName);
      
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('导出失败:', error);
      alert('导出失败，请重试');
    } finally {
      setIsExporting(false);
    }
  };

  // 处理分类变化
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    setFilteredChatLogs(filterChatLogs(chatLogs, category));
  };

  // 加载聊天记录
  const loadChatLogs = async () => {
    setLoading(true);
    try {
      // 使用正确的API端点，增加pageSize以获取更多记录
      const response = await fetch(`${config.AUTH_API_URL}/conversation/logs?page=0&pageSize=1000`, {
        method: 'GET',
        headers: { 
          'Content-Type': 'application/json'
          // 注意：这里移除了Authorization头，因为后端可能不需要
        }
      });
      
      if (response.ok) {
        const result = await response.json();
        console.log('API返回数据:', result); // 调试日志
        
        // 处理后端返回的数据格式
        let logsData: ChatLog[] = [];
        if (result.code === 1 && result.data) {
          console.log('原始数据列表:', result.data.list || result.data); // 调试原始数据
          
          // 从后端返回的格式转换
          logsData = (result.data.list || result.data).map((log: any, index: number) => {
            console.log(`处理第${index}条记录:`, log); // 调试每条记录
            
            // 解析 content JSON 字段
            let content = { question: '', answer: '', shareId: '', appId: '' };
            try {
              if (log.content) {
                content = JSON.parse(log.content);
                console.log(`第${index}条记录解析后的content:`, content);
              }
            } catch (e) {
              console.log(`第${index}条记录JSON解析失败，使用原始content:`, log.content);
              content.question = log.content || '';
            }
            
            const processedLog = {
              id: log.id,
              userId: log.userId,
              username: log.username || '用户' + log.userId,
              email: log.email || '未知',
              question: content.question || log.title || '',
              answer: content.answer || '',
              timestamp: log.createTime,
              shareId: content.shareId || '',
              appId: content.appId || '',
              category: categorizeQuestion(content.question || log.title || '') // 自动分类
            };
            
            console.log(`第${index}条记录处理结果:`, processedLog);
            return processedLog;
          });
        }
        
        console.log('最终处理的数据:', logsData);
        setChatLogs(logsData);
        setFilteredChatLogs(filterChatLogs(logsData, selectedCategory)); // 设置筛选后的数据
        
        // 计算今日对话数量
        const today = new Date().toDateString();
        const todayChats = logsData.filter((log: ChatLog) => {
          const logTime = log.timestamp;
          return logTime ? new Date(logTime).toDateString() === today : false;
        }).length;
        
        setStats(prev => ({ 
          ...prev, 
          totalChats: result.data?.total || logsData.length,
          todayChats 
        }));
      } else {
        console.error('获取聊天记录失败');
        setChatLogs([]);
      }
    } catch (error) {
      console.error('加载聊天记录失败:', error);
      setChatLogs([]);
    } finally {
      setLoading(false);
    }
  };

  // 切换标签页时加载对应数据
  useEffect(() => {
    if (activeTab === 'users') {
      loadUserData();
    } else if (activeTab === 'chats') {
      loadChatLogs();
    }
  }, [activeTab, adminToken]);

  // 登出功能
  const handleLogout = () => {
    localStorage.removeItem('admin-token');
    localStorage.removeItem('admin-user');
    if (onLogout) {
      onLogout();
    }
  };

  // 删除用户
  const handleDeleteUser = async (userId: string | number) => {
    if (!confirm('确定要删除这个用户吗？此操作不可撤销。')) {
      return;
    }

    try {
      const response = await fetch(`${config.AUTH_API_URL}/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      const result = await response.json();
      
      if (result.code === 1) {
        // 删除成功，重新加载用户数据
        loadUserData();
        alert('删除用户成功');
      } else {
        alert(result.msg || '删除用户失败');
      }
    } catch (error) {
      console.error('删除用户失败:', error);
      alert('删除操作失败，请稍后重试');
    }
  };

  return (
    <div className="admin-dashboard-body">
      <div className="admin-dashboard-container">
        <header className="admin-dashboard-header">
          <div className="header-left">
            <h1>FastGPT 认证系统管理后台</h1>
            <p>欢迎回来，{adminUser.username}</p>
          </div>
          <div className="header-right">
            <div className="status-indicator">
              <div className="status-dot"></div>
              <span>系统正常运行</span>
            </div>
            <button className="logout-btn" onClick={handleLogout}>
              退出登录
            </button>
          </div>
        </header>

        {/* 统计卡片 */}
        <div className="stats-section">
          <div className="stat-card">
            <div className="stat-icon users-icon">👥</div>
            <div className="stat-content">
              <h3>总用户数</h3>
              <p>{stats.totalUsers}</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon chats-icon">💬</div>
            <div className="stat-content">
              <h3>总对话数</h3>
              <p>{stats.totalChats}</p>
            </div>
          </div>
          <div className="stat-card">
            <div className="stat-icon today-icon">📈</div>
            <div className="stat-content">
              <h3>今日对话</h3>
              <p>{stats.todayChats}</p>
            </div>
          </div>
        </div>
        
        <div className="tabs-section">
          <div 
            className={`tab ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            <span className="tab-icon">👥</span>
            用户管理
          </div>
          <div 
            className={`tab ${activeTab === 'chats' ? 'active' : ''}`}
            onClick={() => setActiveTab('chats')}
          >
            <span className="tab-icon">💬</span>
            对话记录
          </div>
          <div 
            className={`tab ${activeTab === 'settings' ? 'active' : ''}`}
            onClick={() => setActiveTab('settings')}
          >
            <span className="tab-icon">⚙️</span>
            系统设置
          </div>
        </div>

        {loading && (
          <div className="loading-section">
            <div className="loading-spinner"></div>
            <span>加载中...</span>
          </div>
        )}

        {activeTab === 'users' && !loading && (
          <div className="tab-content">
            <div className="content-header">
              <h2>用户列表</h2>
              <button className="refresh-btn" onClick={loadUserData}>
                🔄 刷新
              </button>
            </div>
            <div className="table-container">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>用户名</th>
                    <th>邮箱</th>
                    <th>角色</th>
                    <th>注册时间</th>
                    <th>操作</th>
                  </tr>
                </thead>
                <tbody>
                  {users.length > 0 ? (
                    users.map(user => (
                      <tr key={user.id}>
                        <td>{user.id}</td>
                        <td>{user.username}</td>
                        <td>{user.email}</td>
                        <td>
                          <span className={`role-badge role-${user.role}`}>
                            {user.role}
                          </span>
                        </td>
                        <td>{user.createdAt ? new Date(user.createdAt).toLocaleString() : '未知'}</td>
                        <td>
                          {user.role !== 'admin' && (
                            <button 
                              className="delete-btn"
                              onClick={() => handleDeleteUser(user.id)}
                            >
                              删除
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="no-data">暂无用户数据</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'chats' && !loading && (
          <div className="tab-content">
            <div className="content-header">
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%', marginBottom: '20px'}}>
                <h2>对话记录</h2>
                <div style={{display: 'flex', gap: '15px', alignItems: 'center'}}>
                  <div style={{display: 'flex', alignItems: 'center', gap: '10px'}}>
                    <label>分类筛选：</label>
                    <select 
                      value={selectedCategory} 
                      onChange={(e) => handleCategoryChange(e.target.value)}
                      style={{
                        padding: '8px 12px',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                        minWidth: '120px'
                      }}
                    >
                      {CATEGORIES.map(category => (
                        <option key={category.value} value={category.value}>
                          {category.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <button 
                    onClick={exportToCSV}
                    disabled={isExporting}
                    style={{
                      background: '#10b981',
                      color: 'white',
                      border: 'none',
                      borderRadius: '8px',
                      padding: '10px 20px',
                      fontSize: '14px',
                      fontWeight: '600',
                      cursor: 'pointer',
                      boxShadow: '0 2px 4px rgba(0,0,0,0.2)'
                    }}
                  >
                    📊 {isExporting ? '导出中...' : '导出CSV'}
                  </button>
                  <button className="refresh-btn" onClick={loadChatLogs}>
                    🔄 刷新
                  </button>
                </div>
              </div>
              <div style={{marginBottom: '15px', color: '#666'}}>
                显示 {selectedCategory ? filteredChatLogs.length : chatLogs.length} 条记录
                {selectedCategory && ` (${selectedCategory}分类)`}
                <br/>
              </div>
            </div>
            <div className="chat-logs-container">
              {(selectedCategory ? filteredChatLogs : chatLogs).length > 0 ? (
                (selectedCategory ? filteredChatLogs : chatLogs).map(log => (
                  <div key={log.id} className="chat-log-card">
                    <div className="chat-log-header">
                      <div className="user-info">
                        <strong>{log.username}</strong> ({log.email})
                        {log.shareId && <span className="share-badge">分享: {log.shareId}</span>}
                        {log.category && <span className="category-badge" style={{
                          background: '#e9ecef',
                          padding: '2px 8px',
                          borderRadius: '12px',
                          fontSize: '12px',
                          marginLeft: '10px'
                        }}>{log.category}</span>}
                      </div>
                      <div className="chat-time">
                        {(log.timestamp || log.createTime) ? new Date(log.timestamp || log.createTime || '').toLocaleString() : '未知时间'}
                      </div>
                    </div>
                    <div className="chat-meta">
                      {log.ipAddress && <span className="meta-item">IP: {log.ipAddress}</span>}
                      {log.appId && <span className="meta-item">应用ID: {log.appId}</span>}
                    </div>
                    <div className="chat-question">
                      <div className="message-label">问题:</div>
                      <div className="message-content">{log.question}</div>
                    </div>
                    <div className="chat-answer">
                      <div className="message-label">回答:</div>
                      <div className="message-content">{log.answer}</div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="no-data">
                  {selectedCategory ? `暂无${selectedCategory}相关的对话记录` : '暂无对话记录'}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'settings' && !loading && (
          <div className="tab-content">
            <h2>系统设置</h2>
            <div className="settings-grid">
              <div className="setting-card">
                <h3>🔐 认证设置</h3>
                <p>配置用户认证相关参数</p>
                <button className="setting-btn">配置</button>
              </div>
              <div className="setting-card">
                <h3>📊 系统监控</h3>
                <p>查看系统运行状态和性能指标</p>
                <button className="setting-btn">查看</button>
              </div>
              <div className="setting-card">
                <h3>📝 日志管理</h3>
                <p>查看和管理系统日志</p>
                <button className="setting-btn">管理</button>
              </div>
              <div className="setting-card">
                <h3>🛡️ 安全设置</h3>
                <p>配置安全策略和访问控制</p>
                <button className="setting-btn">设置</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;